<!-- Blaine Smith
     2-27-2020
    Assignment 6.2 -->
<!DOCTYPE html>

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>
        
    <a href="greatingGenny.php">Greating</a>
        
    </body>
</html>